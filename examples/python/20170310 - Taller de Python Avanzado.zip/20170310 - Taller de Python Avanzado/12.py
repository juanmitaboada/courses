


from os import listdir
from os.path import isfile, join

class Folder(object):
    def __init__(self, folder):
        self.folder_name = folder
        self.files = [f for f in listdir(self.folder_name) if isfile(join(self.folder_name, f))]
    def __getitem__(self, key):
        self.read_file(key)
    def get_files(self):
        return self.files

    def read_file(self, file):
        path_file = "{}/{}".format(self.folder_name, file)
        with open(path_file) as f:
            print f.read()



ruta = '/tmp'

directorio = Folder(ruta)

print directorio.get_files()

directorio['jojo.txt']





