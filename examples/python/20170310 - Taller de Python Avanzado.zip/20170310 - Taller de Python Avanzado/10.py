class A(object):
    def a(self):
        print "Soy a y estoy en la clase A"

    def b(self):
        print "Soy b y estoy en la clase A"

    def c(self):
        print "Soy c y estoy en la clase A"

class A1(object):
    def c(self):
        print "Soy c y estoy en A1"
        super(A1, self).c()

class B(A):
    def b(self):
        print "Soy b y estoy en la clase B"


class C(A1, B):
    def c(self):
        print "Soy c y estoy en la clase C"
        super(C, self).c()

a = A()
b = B()
c = C()



