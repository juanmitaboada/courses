
class A(object): 
    attr = None
    def __init__(self):
        self.attribute = True
    def foo(self,x):
        print "executing foo(%s,%s)"%(self,x) 
    @staticmethod 
    def static_foo(x): 
        print "executing static_foo(%s)"%x a=A()


