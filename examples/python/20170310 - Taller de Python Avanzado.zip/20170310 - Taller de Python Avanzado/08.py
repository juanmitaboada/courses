print [x ** 3 for x in lista if x % 2]
