def impares(lista):
	for x in lista:
		if x % 2:
			yield x
print [x ** 3 for x in impares(lista))

