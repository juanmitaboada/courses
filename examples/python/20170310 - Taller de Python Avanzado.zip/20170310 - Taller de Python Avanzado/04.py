
def impares(lista):
	for x in lista:
		if x % 2:
			yield x
resultado = []
for x in impares(lista):	
resultado.append(x**3)
print resultado


