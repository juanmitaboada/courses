def impares(lista):
	for x in lista:
		if x % 2:
			yield x
def cubo(x):
	return x ** 3
print map(cubo, impares(lista))

