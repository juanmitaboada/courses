resultado = []
for x in lista:
	if x % 2 != 0:
		resultado.append(x * x * x)
print resultado

