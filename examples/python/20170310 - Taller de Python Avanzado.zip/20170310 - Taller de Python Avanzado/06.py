def impares(lista):
	for x in lista:
		if x % 2:
			yield x
print map(lambda x: x ** 3, impares(lista))

