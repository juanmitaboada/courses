resultado = []
for x in lista:
	if x % 2:
		resultado.append(x ** 3)
print resultado
