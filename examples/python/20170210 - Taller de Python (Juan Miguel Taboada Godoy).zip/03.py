# g_max( 1, 3, 2 ) = 3

def g_max(*args, **kwargs):
    if args:
        result=args[0]
        for e in args[1:]:
            result=max(result,e)
    else:
        result = None
    
    return result

result=g_max(1,3,2)         # [1,3,2]
result=g_max(1,3,hola=2)    # [1,3] {'hola':2}
result=g_max()              #Debe salir ???
print("{} debe salir 3".format(result))

