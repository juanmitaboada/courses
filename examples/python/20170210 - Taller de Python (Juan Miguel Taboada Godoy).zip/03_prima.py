def funcion(*args, **kwargs):
    print args
    print kwargs
funcion(1,2,3, hola='hola', caracola='adios')

def function2(a,b,c):
    print a,b,c

a=[1,2,3]
b={'a':3, 'b':2, 'c':1}

c=[4,5]
d={'c':1}

# function2(*c, **d)
# function2(4,5,c=1)

def function3(a,b,c=None):
    if c:
        print a,b,c
    else:
        print a,b


function3(4,5)










