# traduce(rovarspraket)
# consonante*2 + 'o' en medio
# 
# "this is fun" = "tothohisos isos fofunon"

consonantes='bcdfghjklmnpqrstvwxyz'
def traduce(cadena):
    result = ""
    for c in cadena:
        if c in consonantes:
            result+=c+'o'+c
        else:
            result+=c
    return result


print traduce("this is fun")
