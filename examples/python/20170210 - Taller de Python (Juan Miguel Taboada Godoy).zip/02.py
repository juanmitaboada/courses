
# g_len( [ 1, 1, 2, 2 ] ) = 4


# === 1 === =================================
def g_len(arg):
    cuenta=0
    for e in arg:
        cuenta+=1
    
    return cuenta

result = g_len([1,1,2,2])
print("{} debe salir 4".format(result))

# === 2 === =================================
def g_len(arg):
    result = len(arg)
    return result

result = g_len([1,1,2,2])
print("{} debe salir 4".format(result))


