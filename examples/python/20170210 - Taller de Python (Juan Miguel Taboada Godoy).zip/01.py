def g_max(arg1, arg2):
    
    if arg1>arg2:
        algo=arg1
    else:
        algo=arg2
    
    return algo

#print g_max(1,2),"debe salir 2"
#print "{} debe salir 2".format(g_max(1,2))
#print "{0} debe salir 2".format(g_max(1,2),3)
#print "{resultado} debe salir 2".format(resultado=g_max(1,2))


print "{} {} {} {}".format(1,2,3,4)
print "{2} {3} {1} {0}".format(1,2,3,4)
print "{caracola} {hola} {mundo}".format(
        mundo='caracola',
        hola='mundo',
        caracola='hola',
        )
