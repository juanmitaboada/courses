# vocal( "a" ) = True

def vocal_old(arg):
    if type(arg)==str:
        return arg in "aeiou"
    else:
        return False

def vocal(arg):
    return arg in list('aeiou')

print vocal("a")
print vocal("b")
print vocal("abc")
print vocal(3)
print vocal(True)
print vocal(None)

